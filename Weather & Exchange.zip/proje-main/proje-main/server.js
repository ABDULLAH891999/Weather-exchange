const express = require('express');
const axios = require('axios');
const app = express();
const port = 3000;

app.use(express.static('public'));
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/file.html');  // Make sure the path is correct
});

// Function to handle currency conversion
async function convertCurrency(amount, from, to, apiKey) {
    const url = `http://api.exchangeratesapi.io/v1/latest?access_key=${apiKey}&symbols=${from},${to}`;

    try {
        const response = await axios.get(url);
        const rates = response.data.rates;
        let convertedAmount = amount;

        if (from !== 'EUR') {
            // Convert from the original currency to EUR
            convertedAmount = amount / rates[from];
        }
        
        // Now convert from EUR to the target currency
        convertedAmount = convertedAmount * rates[to];

        return convertedAmount.toFixed(2);
    } catch (error) {
        console.error('Error fetching exchange rates:', error);
        return null;
    }
}

// Route to handle conversion requests
app.get('/convert', async (req, res) => {
    const { amount, from, to } = req.query;
    const apiKey = 'ef1e585fbc6d0ac982c5c1bf607dd2e2'; // Put your API key here

    if (!amount || !from || !to) {
        return res.status(400).json({ message: "Missing required query parameters" });
    }

    const convertedAmount = await convertCurrency(amount, from, to, apiKey);
    if (convertedAmount) {
        res.json({ convertedAmount });
    } else {
        res.status(500).json({ message: "Conversion failed due to an error with the external API" });
    }
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
